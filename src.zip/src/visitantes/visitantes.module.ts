import { Module } from '@nestjs/common';
import { VisitantesService } from './visitantes.service';
import { VisitantesController } from './visitantes.controller';

@Module({
  providers: [VisitantesService],
  controllers: [VisitantesController]
})
export class VisitantesModule {}
