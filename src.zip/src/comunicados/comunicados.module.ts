import { Module } from '@nestjs/common';
import { ComunicadosService } from './comunicados.service';
import { ComunicadosController } from './comunicados.controller';

@Module({
  providers: [ComunicadosService],
  controllers: [ComunicadosController]
})
export class ComunicadosModule {}
