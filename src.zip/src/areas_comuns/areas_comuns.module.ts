import { Module } from '@nestjs/common';
import { AreasComunsService } from './areas_comuns.service';
import { AreasComunsController } from './areas_comuns.controller';

@Module({
  providers: [AreasComunsService],
  controllers: [AreasComunsController]
})
export class AreasComunsModule {}
