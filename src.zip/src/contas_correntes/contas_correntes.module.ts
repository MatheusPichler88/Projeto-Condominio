import { Module } from '@nestjs/common';
import { ContasCorrentesService } from './contas_correntes.service';
import { ContasCorrentesController } from './contas_correntes.controller';

@Module({
  providers: [ContasCorrentesService],
  controllers: [ContasCorrentesController]
})
export class ContasCorrentesModule {}
