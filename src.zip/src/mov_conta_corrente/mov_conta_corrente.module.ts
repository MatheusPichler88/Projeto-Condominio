import { Module } from '@nestjs/common';
import { MovContaCorrenteService } from './mov_conta_corrente.service';
import { MovContaCorrenteController } from './mov_conta_corrente.controller';

@Module({
  providers: [MovContaCorrenteService],
  controllers: [MovContaCorrenteController]
})
export class MovContaCorrenteModule {}
