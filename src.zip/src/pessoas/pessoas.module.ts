import { Module } from '@nestjs/common';
import { PessoasService } from './pessoas.service';
import { PessoasController } from './pessoas.controller';

@Module({
  providers: [PessoasService],
  controllers: [PessoasController]
})
export class PessoasModule {}
