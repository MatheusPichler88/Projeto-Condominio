import { Module } from '@nestjs/common';
import { RecebimentosService } from './recebimentos.service';
import { RecebimentosController } from './recebimentos.controller';

@Module({
  providers: [RecebimentosService],
  controllers: [RecebimentosController]
})
export class RecebimentosModule {}
