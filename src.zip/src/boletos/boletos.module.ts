import { Module } from '@nestjs/common';
import { BoletosService } from './boletos.service';
import { BoletosController } from './boletos.controller';

@Module({
  providers: [BoletosService],
  controllers: [BoletosController]
})
export class BoletosModule {}
