import { Module } from '@nestjs/common';
import { ContratosRhService } from './contratos_rh.service';
import { ContratosRhController } from './contratos_rh.controller';

@Module({
  providers: [ContratosRhService],
  controllers: [ContratosRhController]
})
export class ContratosRhModule {}
