import { Module } from '@nestjs/common';
import { ContasReceberService } from './contas_receber.service';
import { ContasReceberController } from './contas_receber.controller';

@Module({
  providers: [ContasReceberService],
  controllers: [ContasReceberController]
})
export class ContasReceberModule {}
