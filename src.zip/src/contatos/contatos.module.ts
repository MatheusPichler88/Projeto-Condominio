import { Module } from '@nestjs/common';
import { ContatosService } from './contatos.service';
import { ContatosController } from './contatos.controller';

@Module({
  providers: [ContatosService],
  controllers: [ContatosController]
})
export class ContatosModule {}
