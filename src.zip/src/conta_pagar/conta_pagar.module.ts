import { Module } from '@nestjs/common';
import { ContaPagarService } from './conta_pagar.service';
import { ContaPagarController } from './conta_pagar.controller';

@Module({
  providers: [ContaPagarService],
  controllers: [ContaPagarController]
})
export class ContaPagarModule {}
